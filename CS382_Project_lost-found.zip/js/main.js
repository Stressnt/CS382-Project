/* ============================================================
   main.js  –  YIC Lost & Found Portal
   CS382 Object Oriented Web Development
   jQuery 3.7 — Dynamic interface & AJAX
   ============================================================ */

'use strict';

/* ── Dark mode bootstraps before jQuery (in <head>), but the
      toggle button wiring runs here inside $(function).        */

$(function () {

    /* ── Dark Mode Toggle ─────────────────────────────────────── */
    function applyDark(dark) {
        $('html').attr('data-theme', dark ? 'dark' : 'light');
        var $btn = $('#darkToggle');
        $btn.find('i').attr('class', dark ? 'fas fa-sun' : 'fas fa-moon');
        $btn.attr({
            title:        dark ? 'Switch to light mode' : 'Switch to dark mode',
            'aria-label': dark ? 'Switch to light mode' : 'Switch to dark mode'
        });
    }

    applyDark($('html').attr('data-theme') === 'dark');

    $('#darkToggle').on('click', function () {
        var isDark = $('html').attr('data-theme') === 'dark';
        localStorage.setItem('theme', isDark ? 'light' : 'dark');
        applyDark(!isDark);
    });

    /* ── Mobile Navigation Toggle ─────────────────────────────── */
    var $toggle = $('#navToggle');
    var $links  = $('#navLinks');

    $toggle.on('click', function () {
        var open = $links.toggleClass('open').hasClass('open');
        $toggle.attr('aria-expanded', open);
        $toggle.find('i').attr('class', open ? 'fas fa-times' : 'fas fa-bars');
    });

    $(document).on('click', function (e) {
        if (!$toggle.is(e.target) && $toggle.has(e.target).length === 0 &&
            !$links.is(e.target)  && $links.has(e.target).length === 0) {
            $links.removeClass('open');
            $toggle.find('i').attr('class', 'fas fa-bars');
        }
    });

    /* ── Flash Message: close button + auto-dismiss ───────────── */
    $(document).on('click', '.flash-close', function () {
        $(this).closest('.flash').fadeOut(300, function () { $(this).remove(); });
    });

    var $flash = $('#flashMsg');
    if ($flash.length) {
        setTimeout(function () {
            $flash.fadeOut(500, function () { $(this).remove(); });
        }, 4000);
    }

    /* ── Password Show / Hide ─────────────────────────────────── */
    $('.toggle-pw').on('click', function () {
        var $inp   = $(this).prev('input');
        var isText = $inp.attr('type') === 'text';
        $inp.attr('type', isText ? 'password' : 'text');
        $(this).find('i').attr('class', isText ? 'fas fa-eye' : 'fas fa-eye-slash');
    });

    /* ── Item Type Toggle (Lost / Found) ──────────────────────── */
    var $typeBtns = $('.type-btn');

    $typeBtns.on('click', function () {
        $typeBtns.removeClass('selected');
        $(this).addClass('selected').find('input[type="radio"]').prop('checked', true);
    });

    $typeBtns.each(function () {
        if ($(this).find('input[type="radio"]').prop('checked')) {
            $(this).addClass('selected');
        }
    });

    /* ── Image Preview on Upload ───────────────────────────────── */
    $('#itemImage').on('change', function () {
        var file     = this.files[0];
        var $preview = $('#imagePreview');

        if (!file) { $preview.hide(); return; }

        var validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if ($.inArray(file.type, validTypes) === -1) {
            showFieldError($(this), 'Only JPG, PNG, GIF, or WEBP images are allowed.');
            this.value = ''; $preview.hide(); return;
        }
        if (file.size > 2 * 1024 * 1024) {
            showFieldError($(this), 'Image must be smaller than 2 MB.');
            this.value = ''; $preview.hide(); return;
        }

        var reader = new FileReader();
        reader.onload = function (e) { $preview.attr('src', e.target.result).show(); };
        reader.readAsDataURL(file);
    });

    /* ── Client-side Form Validation ──────────────────────────── */
    $('#reportForm').on('submit', function (e) {
        clearErrors($(this));
        var valid  = true;
        var $title = $(this).find('#title');
        var $desc  = $(this).find('#description');
        var $loc   = $(this).find('#location');
        var $date  = $(this).find('#date_occurred');
        var $cat   = $(this).find('#category');

        if ($title.val().trim().length < 3)  { showFieldError($title, 'Title must be at least 3 characters.');       valid = false; }
        if ($desc.val().trim().length < 10)   { showFieldError($desc,  'Description must be at least 10 characters.'); valid = false; }
        if ($loc.val().trim().length < 2)     { showFieldError($loc,   'Please enter the location.');                  valid = false; }
        if (!$date.val())                     { showFieldError($date,  'Please select the date.');                     valid = false; }
        if (!$cat.val())                      { showFieldError($cat,   'Please select a category.');                   valid = false; }

        if (!valid) e.preventDefault();
    });

    $('#loginForm').on('submit', function (e) {
        clearErrors($(this));
        var valid  = true;
        var $email = $(this).find('#email');
        var $pass  = $(this).find('#password');

        if (!isValidEmail($email.val())) { showFieldError($email, 'Please enter a valid email.'); valid = false; }
        if ($pass.val().length < 1)      { showFieldError($pass,  'Password is required.');       valid = false; }

        if (!valid) e.preventDefault();
    });

    $('#registerForm').on('submit', function (e) {
        clearErrors($(this));
        var valid  = true;
        var $name  = $(this).find('#name');
        var $email = $(this).find('#email');
        var $pass  = $(this).find('#password');
        var $conf  = $(this).find('#confirm_password');

        if ($name.val().trim().length < 2)  { showFieldError($name,  'Full name must be at least 2 characters.');   valid = false; }
        if (!isValidEmail($email.val()))     { showFieldError($email, 'Please enter a valid @yic.edu.sa email.');    valid = false; }
        if ($pass.val().length < 8)          { showFieldError($pass,  'Password must be at least 8 characters.');   valid = false; }
        if ($conf.val() !== $pass.val())     { showFieldError($conf,  'Passwords do not match.');                   valid = false; }

        if (!valid) e.preventDefault();
    });

    $('#claimForm').on('submit', function (e) {
        clearErrors($(this));
        var $msg = $(this).find('#claim_message');
        if ($msg.val().trim().length < 10) {
            showFieldError($msg, 'Please provide at least 10 characters explaining your claim.');
            e.preventDefault();
        }
    });

    /* ── Confirm Delete / Action ───────────────────────────────── */
    $(document).on('click', '[data-confirm]', function (e) {
        if (!confirm($(this).data('confirm'))) e.preventDefault();
    });

    /* ── Smooth Scroll Anchors ─────────────────────────────────── */
    $(document).on('click', 'a[href^="#"]', function (e) {
        var $target = $($(this).attr('href'));
        if ($target.length) {
            e.preventDefault();
            $('html, body').animate({ scrollTop: $target.offset().top }, 400);
        }
    });

    /* ── Character Counter for Textareas ──────────────────────── */
    $('textarea[maxlength]').each(function () {
        var max      = parseInt($(this).attr('maxlength'), 10);
        var $counter = $('<p class="field-hint">0 / ' + max + ' characters</p>');
        $(this).after($counter);
        $(this).on('input', function () {
            var len = $(this).val().length;
            $counter.text(len + ' / ' + max + ' characters')
                    .css('color', len > max * 0.9 ? 'var(--warning)' : '');
        });
    });

    /* ================================================================
       AJAX LIVE SEARCH  —  items.php
       Fires on keystroke (debounced 350 ms) and on filter change.
       Results replace #resultsGrid without a full page reload.
    ================================================================ */
    var $searchInput  = $('#liveSearch');
    var $resultsGrid  = $('#resultsGrid');
    var $resultsCount = $('#resultsCount');
    var searchXHR     = null;
    var searchTimer   = null;

    if ($searchInput.length && $resultsGrid.length) {

        function doSearch() {
            var params = {
                search:   $searchInput.val(),
                type:     $('[name="type"]').val()     || '',
                category: $('[name="category"]').val() || '',
                status:   $('[name="status"]').val()   || 'active',
                sort:     $('[name="sort"]').val()     || 'newest'
            };

            if (searchXHR) searchXHR.abort();
            $resultsGrid.addClass('search-loading');

            searchXHR = $.getJSON('ajax/search.php', params)
                .done(function (data) {
                    $resultsGrid.removeClass('search-loading');

                    if ($resultsCount.length) {
                        $resultsCount.text(
                            data.total + ' item' + (data.total !== 1 ? 's' : '') + ' found'
                        );
                    }

                    if (data.items.length === 0) {
                        $resultsGrid.html(
                            '<div class="empty-state ajax-empty">' +
                                '<i class="fas fa-search-minus"></i>' +
                                '<h3>No items found</h3>' +
                                '<p>Try adjusting your filters or search terms.</p>' +
                            '</div>'
                        );
                        return;
                    }

                    var html = '';
                    $.each(data.items, function (i, item) {
                        var typeBadge   = '<span class="badge-' + item.type + '">'   + cap(item.type)   + '</span>';
                        var statusBadge = '<span class="badge-' + item.status + '">' + cap(item.status) + '</span>';
                        var media       = item.image
                            ? '<img src="uploads/items/' + esc(item.image) + '" alt="' + esc(item.title) + '" class="card-img">'
                            : '<div class="card-img-placeholder"><i class="' + esc(item.icon) + '"></i></div>';
                        var desc = item.description.length > 80
                            ? esc(item.description.substring(0, 80)) + '&hellip;'
                            : esc(item.description);

                        html +=
                            '<article class="card">' +
                                media +
                                '<div class="card-body">' +
                                    '<div class="card-badges">' + typeBadge + ' ' + statusBadge + '</div>' +
                                    '<h3 class="card-title">' + esc(item.title) + '</h3>' +
                                    '<p class="card-text">' + desc + '</p>' +
                                    '<div class="item-meta-list">' +
                                        '<span><i class="fas fa-tag"></i> '             + esc(item.category)     + '</span>' +
                                        '<span><i class="fas fa-map-marker-alt"></i> ' + esc(item.location)      + '</span>' +
                                        '<span><i class="fas fa-calendar"></i> '       + esc(item.date_occurred) + '</span>' +
                                    '</div>' +
                                '</div>' +
                                '<div class="card-footer flex items-center justify-between">' +
                                    '<span class="card-footer-meta">by ' + esc(item.reporter_name) + '</span>' +
                                    '<a href="item-detail.php?id=' + item.id + '" class="btn btn-primary btn-sm">' +
                                        'Details <i class="fas fa-arrow-right"></i>' +
                                    '</a>' +
                                '</div>' +
                            '</article>';
                    });

                    $resultsGrid.html(html);
                })
                .fail(function (xhr) {
                    if (xhr.statusText !== 'abort') {
                        $resultsGrid.removeClass('search-loading');
                    }
                });
        }

        $searchInput.on('input', function () {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(doSearch, 350);
        });

        $('[name="type"], [name="category"], [name="status"], [name="sort"]').on('change', function () {
            doSearch();
        });
    }

}); /* end $(function) */

/* ── Shared Helpers ───────────────────────────────────────────── */
function showFieldError($field, msg) {
    if (!$field || !$field.length) return;
    $field.css('border-color', 'var(--danger)');
    var $err = $field.parent().find('.field-error');
    if (!$err.length) { $err = $('<p class="field-error"></p>').appendTo($field.parent()); }
    $err.text(msg);
}

function clearErrors($form) {
    $form.find('.field-error').remove();
    $form.find('input, textarea, select').css('border-color', '');
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test($.trim(email));
}

function esc(str) {
    return $('<div>').text(String(str)).html();
}

function cap(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}
