<?php
require_once 'includes/header.php';

$db = getDB();
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) { header('Location: items.php'); exit; }

$stmt = $db->prepare("
    SELECT i.*, u.name AS reporter_name, u.email AS reporter_email
    FROM items i
    JOIN users u ON u.id = i.user_id
    WHERE i.id = ?
");
$stmt->execute([$id]);
$item = $stmt->fetch();

if (!$item) { header('Location: items.php'); exit; }
$pageTitle = e($item['title']);

$alreadyClaimed = false;
if ($user) {
    $chk = $db->prepare(
        'SELECT id FROM claims WHERE item_id = ? AND claimant_id = ? LIMIT 1'
    );
    $chk->execute([$id, $user['id']]);
    $alreadyClaimed = (bool)$chk->fetch();
}

$claimErrors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'claim') {
    if (!$user) {
        setFlash('error', 'Please login to submit a claim.');
        header("Location: login.php"); exit;
    }
    verifyCsrf();

    $message = trim($_POST['claim_message'] ?? '');
    if (strlen($message) < 10) {
        $claimErrors[] = 'Please provide at least 10 characters describing your claim.';
    }
    if ($item['user_id'] === $user['id']) {
        $claimErrors[] = 'You cannot claim your own item.';
    }
    if ($alreadyClaimed) {
        $claimErrors[] = 'You have already submitted a claim for this item.';
    }

    if (empty($claimErrors)) {
        $ins = $db->prepare(
            'INSERT INTO claims (item_id, claimant_id, message) VALUES (?, ?, ?)'
        );
        $ins->execute([$id, $user['id'], $message]);

        // Notify claimant
        createNotification(
            $user['id'],
            'Your claim for "' . $item['title'] . '" has been submitted and is pending review.',
            "item-detail.php?id=$id"
        );
        // Notify reporter
        createNotification(
            $item['user_id'],
            'Someone has claimed your ' . $item['type'] . ' item "' . $item['title'] . '".',
            "dashboard.php"
        );

        $alreadyClaimed = true;
        setFlash('success', 'Claim submitted! You will be notified once admin reviews it.');
        header("Location: item-detail.php?id=$id"); exit;
    }
}

// ── Fetch approved claims count ──
$claimCount = (int)$db->prepare(
    'SELECT COUNT(*) FROM claims WHERE item_id = ?'
)->execute([$id]) ? 0 : 0;
$claimStmt = $db->prepare('SELECT COUNT(*) FROM claims WHERE item_id = ?');
$claimStmt->execute([$id]);
$claimCount = (int)$claimStmt->fetchColumn();

$catIcons = [
    'Electronics' => 'fas fa-laptop',  'Bags'     => 'fas fa-briefcase',
    'ID / Cards'  => 'fas fa-id-card', 'Keys'     => 'fas fa-key',
    'Accessories' => 'fas fa-glasses', 'Books'    => 'fas fa-book',
    'Clothing'    => 'fas fa-tshirt',  'Sports'   => 'fas fa-football-ball',
    'Documents'   => 'fas fa-file-alt','Other'    => 'fas fa-box',
];
$catIcon = $catIcons[$item['category']] ?? 'fas fa-box';
?>

<div class="page-header">
    <div class="page-header-inner">
        <div>
            <div class="breadcrumb">
                <a href="index.php">Home</a><span>/</span>
                <a href="items.php">Browse</a><span>/</span>
                <?= e(mb_strimwidth($item['title'], 0, 40, '…')) ?>
            </div>
            <h1><?= e($item['title']) ?></h1>
        </div>
        <div class="flex gap-8">
            <span class="badge-<?= $item['type'] ?>" style="font-size:.9rem;padding:8px 16px">
                <?= ucfirst($item['type']) ?>
            </span>
            <span class="badge-<?= $item['status'] ?>" style="font-size:.9rem;padding:8px 16px">
                <?= ucfirst($item['status']) ?>
            </span>
        </div>
    </div>
</div>

<div class="container">
    <div class="item-detail-grid">
        
        <div>
            <?php if ($item['image']): ?>
                <img src="uploads/items/<?= e($item['image']) ?>"
                     alt="<?= e($item['title']) ?>" class="item-img-large">
            <?php else: ?>
                <div class="item-img-placeholder-large">
                    <i class="<?= $catIcon ?>"></i>
                </div>
            <?php endif; ?>

            <div style="background:var(--white);border:1px solid var(--border);border-radius:var(--radius);padding:28px;margin-top:20px">
                <h2 style="font-size:1.2rem;margin-bottom:12px">Description</h2>
                <p style="line-height:1.75;color:var(--text)"><?= nl2br(e($item['description'])) ?></p>

                <hr>

                <h3 style="font-size:1rem;margin-bottom:14px;margin-top:14px">Item Details</h3>
                <div class="item-meta">
                    <div class="meta-row">
                        <i class="fas fa-tag"></i>
                        <span class="meta-label">Category:</span>
                        <span><?= e($item['category']) ?></span>
                    </div>
                    <div class="meta-row">
                        <i class="fas fa-map-marker-alt"></i>
                        <span class="meta-label">Location:</span>
                        <span><?= e($item['location']) ?></span>
                    </div>
                    <div class="meta-row">
                        <i class="fas fa-calendar-alt"></i>
                        <span class="meta-label">Date:</span>
                        <span><?= date('d F Y', strtotime($item['date_occurred'])) ?></span>
                    </div>
                    <div class="meta-row">
                        <i class="fas fa-user"></i>
                        <span class="meta-label">Reported by:</span>
                        <span><?= e($item['reporter_name']) ?></span>
                    </div>
                    <div class="meta-row">
                        <i class="fas fa-clock"></i>
                        <span class="meta-label">Posted:</span>
                        <span><?= date('d M Y, h:i A', strtotime($item['created_at'])) ?></span>
                    </div>
                    <?php if ($claimCount > 0): ?>
                    <div class="meta-row">
                        <i class="fas fa-hand-paper"></i>
                        <span class="meta-label">Claims:</span>
                        <span><?= $claimCount ?> claim<?= $claimCount !== 1 ? 's' : '' ?> submitted</span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div>
            <div class="sidebar-card">
                <?php if ($item['type'] === 'found' && $item['status'] === 'active'): ?>
                    
                    <h3 style="font-size:1.1rem;margin-bottom:8px">
                        <i class="fas fa-hand-paper" style="color:var(--primary)"></i>
                        Is this yours?
                    </h3>
                    <p style="font-size:.88rem;color:var(--text-muted);margin-bottom:16px">
                        If this item belongs to you, submit a claim with a description that proves ownership.
                    </p>

                    <?php if (!$user): ?>
                        <a href="login.php" class="btn btn-primary btn-block">
                            <i class="fas fa-sign-in-alt"></i> Login to Claim
                        </a>
                    <?php elseif ($user['id'] === $item['user_id']): ?>
                        <div class="flash flash-success" style="border-radius:8px">
                            <i class="fas fa-info-circle"></i>
                            You reported this item.
                        </div>
                    <?php elseif ($alreadyClaimed): ?>
                        <div class="flash flash-success" style="border-radius:8px">
                            <i class="fas fa-check-circle"></i>
                            You have already submitted a claim. Please wait for admin review.
                        </div>
                    <?php else: ?>
                        <?php if (!empty($claimErrors)): ?>
                            <div class="flash flash-error" style="border-radius:8px;margin-bottom:12px">
                                <i class="fas fa-exclamation-circle"></i>
                                <?= implode('<br>', array_map('htmlspecialchars', $claimErrors)) ?>
                            </div>
                        <?php endif; ?>
                        <form id="claimForm" method="POST" action="item-detail.php?id=<?= $id ?>">
                            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                            <input type="hidden" name="action" value="claim">
                            <div class="form-group">
                                <label for="claim_message">Proof of Ownership</label>
                                <textarea id="claim_message" name="claim_message"
                                          placeholder="Describe identifying features, serial numbers, what was inside, etc."
                                          required maxlength="1000" rows="5"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-paper-plane"></i> Submit Claim
                            </button>
                        </form>
                    <?php endif; ?>

                <?php elseif ($item['type'] === 'lost' && $item['status'] === 'active'): ?>
                    
                    <h3 style="font-size:1.1rem;margin-bottom:8px">
                        <i class="fas fa-info-circle" style="color:var(--primary)"></i>
                        Did you find this?
                    </h3>
                    <p style="font-size:.88rem;color:var(--text-muted);margin-bottom:16px">
                        If you found this item, please bring it to the admin office or contact the reporter.
                    </p>
                    <?php if ($user && $item['reporter_email']): ?>
                    <div style="background:var(--bg);border-radius:8px;padding:14px;font-size:.88rem">
                        <strong>Contact Reporter:</strong><br>
                        <i class="fas fa-user"></i> <?= e($item['reporter_name']) ?><br>
                        <i class="fas fa-envelope"></i>
                        <a href="mailto:<?= e($item['reporter_email']) ?>">
                            <?= e($item['reporter_email']) ?>
                        </a>
                    </div>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="flash flash-success" style="border-radius:8px">
                        <i class="fas fa-check-circle"></i>
                        This item has been <?= e($item['status']) ?>. It is no longer available.
                    </div>
                <?php endif; ?>

                <hr>
                <a href="items.php" class="btn btn-outline btn-block btn-sm">
                    <i class="fas fa-arrow-left"></i> Back to Browse
                </a>

                <?php if ($user && ($user['id'] === $item['user_id'] || isAdmin())): ?>
                <div style="margin-top:12px">
                    <a href="report.php?edit=<?= $item['id'] ?>" class="btn btn-outline btn-block btn-sm">
                        <i class="fas fa-edit"></i> Edit Item
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
