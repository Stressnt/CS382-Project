<?php
$pageTitle = 'Notifications';
require_once 'includes/header.php';
requireLogin();

$db  = getDB();
$uid = $user['id'];

$db->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?')->execute([$uid]);

$stmt = $db->prepare(
    'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50'
);
$stmt->execute([$uid]);
$notifications = $stmt->fetchAll();
?>

<div class="page-header">
    <div class="page-header-inner">
        <div>
            <div class="breadcrumb">
                <a href="index.php">Home</a><span>/</span>
                <a href="dashboard.php">Dashboard</a><span>/</span> Notifications
            </div>
            <h1>Notifications</h1>
            <p>Updates on your items and claims</p>
        </div>
    </div>
</div>

<div class="container" style="padding-top:32px;padding-bottom:48px;max-width:760px">

    <div style="background:var(--white);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden">
        <div style="padding:20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
            <h2 style="font-size:1.1rem;font-weight:700">
                <i class="fas fa-bell" style="color:var(--primary)"></i>
                All Notifications
            </h2>
            <span style="font-size:.85rem;color:var(--text-muted)"><?= count($notifications) ?> total</span>
        </div>

        <?php if (empty($notifications)): ?>
            <div class="empty-state">
                <i class="fas fa-bell-slash"></i>
                <h3>No notifications</h3>
                <p>You're all caught up! Notifications will appear here when there are updates to your items or claims.</p>
            </div>
        <?php else: ?>
            <?php foreach ($notifications as $n): ?>
            <div class="notif-item <?= !$n['is_read'] ? 'unread' : '' ?>">
                <div class="notif-icon">
                    <i class="fas fa-bell"></i>
                </div>
                <div class="notif-text">
                    <?php if ($n['link']): ?>
                        <a href="<?= e($n['link']) ?>" style="color:inherit">
                            <?= e($n['message']) ?>
                        </a>
                    <?php else: ?>
                        <?= e($n['message']) ?>
                    <?php endif; ?>
                    <div class="notif-time">
                        <i class="fas fa-clock"></i>
                        <?= date('d M Y, h:i A', strtotime($n['created_at'])) ?>
                    </div>
                </div>
                <?php if (!$n['is_read']): ?>
                    <div class="notif-dot"></div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div style="margin-top:20px">
        <a href="dashboard.php" class="btn btn-outline btn-sm">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
