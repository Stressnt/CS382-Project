<?php
$pageTitle = 'Login';
$bodyClass = 'auth-page';
require_once 'config/db.php';
require_once 'includes/auth.php';
startSession();

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if (empty($password)) {
        $errors[] = 'Password is required.';
    }

    if (empty($errors)) {
        $db   = getDB();
        $stmt = $db->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);

            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_role'] = $user['role'];

            setFlash('success', 'Welcome back, ' . $user['name'] . '!');

            $redirect = isAdmin() ? 'admin/dashboard.php' : 'dashboard.php';
            header("Location: $redirect");
            exit;
        } else {
            $errors[] = 'Invalid email or password. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | YIC Lost & Found</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
          crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="auth-page">
<nav class="navbar">
    <div class="nav-container">
        <a href="index.php" class="nav-brand">
            <i class="fas fa-search-location"></i>
            <span>YIC Lost &amp; Found</span>
        </a>
    </div>
</nav>

<main class="main-content" style="display:flex;align-items:center;justify-content:center;padding:40px 20px">
    <div class="auth-card">
        <div class="auth-logo">
            <i class="fas fa-sign-in-alt" style="color:var(--primary)"></i>
            <h1>Welcome Back</h1>
            <p>Sign in to your YIC account</p>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="flash flash-error" style="border-radius:8px;margin-bottom:20px">
                <i class="fas fa-exclamation-circle"></i>
                <div><?= implode('<br>', array_map('htmlspecialchars', $errors)) ?></div>
            </div>
        <?php endif; ?>

        <form id="loginForm" method="POST" action="login.php" novalidate>
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

            <div class="form-group">
                <label for="email"><i class="fas fa-envelope"></i> Email Address</label>
                <input type="email" id="email" name="email"
                       value="<?= isset($email) ? e($email) : '' ?>"
                       placeholder="you@yic.edu.sa" required autocomplete="email">
            </div>

            <div class="form-group">
                <label for="password"><i class="fas fa-lock"></i> Password</label>
                <div class="password-wrapper">
                    <input type="password" id="password" name="password"
                           placeholder="Enter your password" required autocomplete="current-password">
                    <button type="button" class="toggle-pw" aria-label="Show/hide password">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-block" style="margin-top:8px">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>

        <div class="divider"><span>Don't have an account?</span></div>
        <a href="register.php" class="btn btn-outline btn-block">
            <i class="fas fa-user-plus"></i> Create Account
        </a>

        <p class="auth-link" style="margin-top:16px">
            <a href="index.php"><i class="fas fa-home"></i> Back to Home</a>
        </p>

        
        <div style="margin-top:20px;padding:12px;background:var(--bg);border-radius:8px;font-size:.8rem;color:var(--text-muted)">
            <strong>Demo Credentials:</strong><br>
            Admin: admin@yic.edu.sa / Password123<br>
            Student: ahmed@yic.edu.sa / Password123
        </div>
    </div>
</main>

<script src="js/main.js"></script>
</body>
</html>
