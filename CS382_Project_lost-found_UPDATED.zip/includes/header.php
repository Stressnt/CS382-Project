<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
startSession();

$pageTitle = $pageTitle ?? 'YIC Lost & Found';
$user      = currentUser();
$notifCount = ($user) ? unreadCount($user['id']) : 0;

$isAdmin = defined('ADMIN_PAGE');
$root    = $isAdmin ? '../' : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> | YIC Lost & Found</title>
    <link rel="stylesheet" href="<?= $root ?>css/style.css">
    
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
          integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
          crossorigin="anonymous" referrerpolicy="no-referrer">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Dark mode must run before paint to prevent flash -->
    <script>(function(){var t=localStorage.getItem('theme');if(t==='dark')document.documentElement.setAttribute('data-theme','dark');}());</script>
    <!-- jQuery loaded in <head> so main.js $(function(){}) is available immediately -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
            integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
            crossorigin="anonymous"></script>
    <!-- Root path for AJAX calls — resolves correctly from admin pages too -->
    <script>var ROOT = '<?= $root ?>';</script>
</head>
<body class="<?= $bodyClass ?? '' ?>">

<?php
$isAuthPage = (!$isAdmin && in_array(basename($_SERVER['PHP_SELF']), ['login.php','register.php']));
?>
<?php if ($isAuthPage): ?>
<div class="auth-bg" aria-hidden="true">
    <div class="auth-orb-gold"></div>
    <div class="auth-watermark">
        <i class="fas fa-search-location"></i>
        YIC Lost &amp; Found
    </div>
</div>
<?php endif; ?>
<nav class="navbar" id="mainNav">
    <div class="nav-container">

        
        <a href="<?= $root ?>index.php" class="nav-brand">
            <i class="fas fa-search-location"></i>
            <span>YIC Lost &amp; Found</span>
        </a>

        
        <button class="dark-toggle" id="darkToggle" aria-label="Switch to dark mode" title="Switch to dark mode">
            <i class="fas fa-moon"></i>
        </button>

        <button class="nav-toggle" id="navToggle" aria-label="Toggle menu">
            <i class="fas fa-bars"></i>
        </button>

        
        <ul class="nav-links" id="navLinks">
            <li><a href="<?= $root ?>index.php"
                   class="<?= (basename($_SERVER['PHP_SELF']) === 'index.php') ? 'active' : '' ?>">
                    <i class="fas fa-home"></i> Home
               </a></li>
            <li><a href="<?= $root ?>items.php"
                   class="<?= (basename($_SERVER['PHP_SELF']) === 'items.php') ? 'active' : '' ?>">
                    <i class="fas fa-list"></i> Browse Items
               </a></li>

            <?php if ($user): ?>
                <li><a href="<?= $root ?>report.php"
                       class="<?= (basename($_SERVER['PHP_SELF']) === 'report.php') ? 'active' : '' ?>">
                        <i class="fas fa-plus-circle"></i> Report Item
                   </a></li>
                <li><a href="<?= $root ?>dashboard.php"
                       class="<?= (basename($_SERVER['PHP_SELF']) === 'dashboard.php' && !defined('ADMIN_PAGE')) ? 'active' : '' ?>">
                        <i class="fas fa-user"></i> Dashboard
                   </a></li>
                <li><a href="<?= $root ?>profile.php"
                       class="<?= (basename($_SERVER['PHP_SELF']) === 'profile.php') ? 'active' : '' ?>">
                        <i class="fas fa-user-circle"></i> Profile
                   </a></li>
                <?php if (isAdmin()): ?>
                <li><a href="<?= $root ?>admin/dashboard.php"
                       class="<?= defined('ADMIN_PAGE') ? 'active' : '' ?>">
                        <i class="fas fa-shield-alt"></i> Admin
                   </a></li>
                <?php endif; ?>
                <li>
                    <a href="<?= $root ?>notifications.php" class="notif-link">
                        <i class="fas fa-bell"></i> Notifications
                        <?php if ($notifCount > 0): ?>
                            <span class="badge"><?= $notifCount ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li><a href="<?= $root ?>logout.php" class="btn-logout">
                        <i class="fas fa-sign-out-alt"></i> Logout
                   </a></li>
            <?php else: ?>
                <li><a href="<?= $root ?>login.php" class="btn-nav-login">
                        <i class="fas fa-sign-in-alt"></i> Login
                   </a></li>
                <li><a href="<?= $root ?>register.php" class="btn-nav-register">
                        <i class="fas fa-user-plus"></i> Register
                   </a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<?php
$success = getFlash('success');
$error   = getFlash('error');
?>
<?php if ($success): ?>
    <div class="flash flash-success" id="flashMsg">
        <i class="fas fa-check-circle"></i>
        <?= e($success) ?>
        <button class="flash-close">&times;</button>
    </div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="flash flash-error" id="flashMsg">
        <i class="fas fa-exclamation-circle"></i>
        <?= e($error) ?>
        <button class="flash-close">&times;</button>
    </div>
<?php endif; ?>

<main class="main-content">
