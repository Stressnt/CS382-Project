<?php
/* ── All logic runs BEFORE any HTML output so header() redirects work ── */
require_once 'config/db.php';
require_once 'includes/auth.php';
startSession();

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$db  = getDB();
$me  = currentUser();

/* Fetch full row — session may not store every field (email, phone, password) */
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$me['id']]);
$userRow = $stmt->fetch();

$profileErrors  = [];
$passwordErrors = [];

/* ── Handle profile update ──────────────────────────────────── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    verifyCsrf();
    $name  = trim($_POST['name']  ?? '');
    $phone = trim($_POST['phone'] ?? '');

    if (mb_strlen($name) < 2) {
        $profileErrors['name'] = 'Name must be at least 2 characters.';
    }

    if (empty($profileErrors)) {
        $db->prepare("UPDATE users SET name = ?, phone = ? WHERE id = ?")
           ->execute([$name, $phone ?: null, $me['id']]);
        setFlash('success', 'Profile updated successfully.');
        header('Location: profile.php');
        exit;
    }
}

/* ── Handle password change ─────────────────────────────────── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    verifyCsrf();
    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password']     ?? '';
    $conf    = $_POST['confirm_password'] ?? '';

    if (!password_verify($current, $userRow['password'])) {
        $passwordErrors['current_password'] = 'Current password is incorrect.';
    } elseif (strlen($new) < 8) {
        $passwordErrors['new_password'] = 'New password must be at least 8 characters.';
    } elseif ($new !== $conf) {
        $passwordErrors['confirm_password'] = 'Passwords do not match.';
    }

    if (empty($passwordErrors)) {
        $db->prepare("UPDATE users SET password = ? WHERE id = ?")
           ->execute([password_hash($new, PASSWORD_DEFAULT), $me['id']]);
        setFlash('success', 'Password changed successfully.');
        header('Location: profile.php');
        exit;
    }

    /* Re-fetch userRow after failed attempt (password hash hasn't changed) */
}

/* ── Fetch user activity stats ──────────────────────────────── */
$statStmt = $db->prepare("
    SELECT
        COUNT(DISTINCT i.id) AS item_count,
        COUNT(DISTINCT c.id) AS claim_count
    FROM users u
    LEFT JOIN items  i ON i.user_id     = u.id
    LEFT JOIN claims c ON c.claimant_id = u.id
    WHERE u.id = ?
");
$statStmt->execute([$me['id']]);
$userStats = $statStmt->fetch();

/* ── Now safe to output HTML ──────────────────────────────────  */
$pageTitle = 'My Profile';
require_once 'includes/header.php';
?>

<div class="page-header">
    <div class="page-header-inner">
        <div>
            <div class="breadcrumb">
                <a href="index.php">Home</a>
                <span>/</span>
                <a href="dashboard.php">Dashboard</a>
                <span>/</span> My Profile
            </div>
            <h1>My Profile</h1>
            <p>Manage your account information and password</p>
        </div>
    </div>
</div>

<div class="container container--padded">
    <div class="profile-grid">

        <!-- Left column: avatar card -->
        <div>
            <div class="card profile-card">
                <div class="profile-card-header">
                    <div class="profile-avatar">
                        <?= mb_strtoupper(mb_substr($userRow['name'], 0, 1)) ?>
                    </div>
                    <div class="profile-name"><?= e($userRow['name']) ?></div>
                    <div class="profile-email"><?= e($userRow['email']) ?></div>
                    <span class="role-badge role-<?= $userRow['role'] ?>">
                        <i class="fas fa-<?= $userRow['role'] === 'admin' ? 'shield-alt' : 'user-graduate' ?>"></i>
                        <?= ucfirst($userRow['role']) ?>
                    </span>
                </div>

                <div class="profile-stats">
                    <div class="profile-stat">
                        <div class="profile-stat-num"><?= (int)$userStats['item_count'] ?></div>
                        <div class="profile-stat-lbl">Items Reported</div>
                    </div>
                    <div class="profile-stat">
                        <div class="profile-stat-num"><?= (int)$userStats['claim_count'] ?></div>
                        <div class="profile-stat-lbl">Claims Made</div>
                    </div>
                </div>

                <div class="profile-card-footer">
                    <small class="text-muted">
                        <i class="fas fa-calendar-alt"></i>
                        Member since <?= date('d M Y', strtotime($userRow['created_at'])) ?>
                    </small>
                </div>
            </div>

            <div class="mt-16">
                <a href="dashboard.php" class="btn btn-outline btn-block">
                    <i class="fas fa-tachometer-alt"></i> Go to Dashboard
                </a>
            </div>
        </div>

        <!-- Right column: edit forms -->
        <div>

            <!-- Edit Profile -->
            <div class="card mb-24">
                <div class="card-body">
                    <h2 class="form-title"><i class="fas fa-user-edit"></i> Edit Profile</h2>
                    <p class="form-sub">Update your name and phone number.</p>

                    <?php if (!empty($profileErrors)): ?>
                        <?php foreach ($profileErrors as $err): ?>
                            <div class="flash flash-error mb-16">
                                <i class="fas fa-exclamation-circle"></i> <?= e($err) ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <form method="post" id="profileForm">
                        <input type="hidden" name="csrf_token"     value="<?= csrfToken() ?>">
                        <input type="hidden" name="update_profile" value="1">

                        <div class="form-row">
                            <div class="form-group">
                                <label for="name">Full Name</label>
                                <input type="text" id="name" name="name"
                                       value="<?= e(!empty($profileErrors) ? ($_POST['name'] ?? '') : $userRow['name']) ?>"
                                       required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone <span class="text-muted">(optional)</span></label>
                                <input type="tel" id="phone" name="phone"
                                       value="<?= e(!empty($profileErrors) ? ($_POST['phone'] ?? '') : ($userRow['phone'] ?? '')) ?>"
                                       placeholder="+966 5xx xxx xxxx">
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" value="<?= e($userRow['email']) ?>" disabled>
                            <p class="field-hint">Email cannot be changed after registration.</p>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                    </form>
                </div>
            </div>

            <!-- Change Password -->
            <div class="card">
                <div class="card-body">
                    <h2 class="form-title"><i class="fas fa-lock"></i> Change Password</h2>
                    <p class="form-sub">Choose a strong password of at least 8 characters.</p>

                    <?php if (!empty($passwordErrors)): ?>
                        <?php foreach ($passwordErrors as $err): ?>
                            <div class="flash flash-error mb-16">
                                <i class="fas fa-exclamation-circle"></i> <?= e($err) ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <form method="post" id="passwordForm">
                        <input type="hidden" name="csrf_token"      value="<?= csrfToken() ?>">
                        <input type="hidden" name="change_password"  value="1">

                        <div class="form-group">
                            <label for="current_password">Current Password</label>
                            <div class="password-wrapper">
                                <input type="password" id="current_password"
                                       name="current_password" required>
                                <button type="button" class="toggle-pw">
                                    <i class="fas fa-eye-slash"></i>
                                </button>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <div class="password-wrapper">
                                    <input type="password" id="new_password"
                                           name="new_password" minlength="8" required>
                                    <button type="button" class="toggle-pw">
                                        <i class="fas fa-eye-slash"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <div class="password-wrapper">
                                    <input type="password" id="confirm_password"
                                           name="confirm_password" required>
                                    <button type="button" class="toggle-pw">
                                        <i class="fas fa-eye-slash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-key"></i> Change Password
                        </button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
