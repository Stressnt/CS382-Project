<?php
/* ============================================================
   ajax/search.php  –  YIC Lost & Found Portal
   CS382 AJAX Feature: Live item search
   Returns JSON: { total: int, items: array }
   ============================================================ */

require_once '../config/db.php';
header('Content-Type: application/json; charset=utf-8');

$db = getDB();

$search   = trim($_GET['search']   ?? '');
$type     = $_GET['type']          ?? '';
$category = $_GET['category']      ?? '';
$status   = $_GET['status']        ?? 'active';
$sort     = $_GET['sort']          ?? 'newest';

$where  = [];
$params = [];

if ($search !== '') {
    $where[]  = '(i.title LIKE ? OR i.description LIKE ? OR i.location LIKE ?)';
    $like     = "%$search%";
    $params   = array_merge($params, [$like, $like, $like]);
}
if (in_array($type, ['lost', 'found'], true)) {
    $where[]  = 'i.type = ?';
    $params[] = $type;
}
if ($category !== '') {
    $where[]  = 'i.category = ?';
    $params[] = $category;
}
if (in_array($status, ['active', 'claimed', 'closed'], true)) {
    $where[]  = 'i.status = ?';
    $params[] = $status;
}

$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$orderSQL = match ($sort) {
    'oldest' => 'ORDER BY i.created_at ASC',
    'a-z'    => 'ORDER BY i.title ASC',
    default  => 'ORDER BY i.created_at DESC',
};

// Total count (for the counter label)
$countStmt = $db->prepare("SELECT COUNT(*) FROM items i $whereSQL");
$countStmt->execute($params);
$total = (int) $countStmt->fetchColumn();

// Fetch first page of results
$stmt = $db->prepare("
    SELECT i.id, i.type, i.title, i.description, i.category,
           i.location, i.status, i.image, i.date_occurred,
           u.name AS reporter_name
    FROM items i
    JOIN users u ON u.id = i.user_id
    $whereSQL $orderSQL
    LIMIT 9
");
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$catIcons = [
    'Electronics' => 'fas fa-laptop',
    'Bags'        => 'fas fa-briefcase',
    'ID / Cards'  => 'fas fa-id-card',
    'Keys'        => 'fas fa-key',
    'Accessories' => 'fas fa-glasses',
    'Books'       => 'fas fa-book',
    'Clothing'    => 'fas fa-tshirt',
    'Sports'      => 'fas fa-football-ball',
    'Documents'   => 'fas fa-file-alt',
    'Other'       => 'fas fa-box',
];

$items = array_map(static function (array $row) use ($catIcons): array {
    return [
        'id'            => (int) $row['id'],
        'type'          => $row['type'],
        'title'         => $row['title'],
        'description'   => $row['description'],
        'category'      => $row['category'],
        'location'      => $row['location'],
        'status'        => $row['status'],
        'image'         => $row['image'],
        'icon'          => $catIcons[$row['category']] ?? 'fas fa-box',
        'date_occurred' => date('d M Y', strtotime($row['date_occurred'])),
        'reporter_name' => $row['reporter_name'],
    ];
}, $rows);

echo json_encode(['total' => $total, 'items' => $items], JSON_UNESCAPED_UNICODE);
