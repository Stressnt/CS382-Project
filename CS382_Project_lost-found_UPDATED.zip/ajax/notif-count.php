<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
startSession();

header('Content-Type: application/json');

$user = currentUser();
if (!$user) {
    echo json_encode(['count' => 0]);
    exit;
}

echo json_encode(['count' => unreadCount((int)$user['id'])]);
