<?php
define('ADMIN_PAGE', true);
$pageTitle = 'Admin Dashboard';
require_once '../includes/header.php';
requireAdmin();

$db = getDB();

$totalUsers    = (int)$db->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn();
$totalItems    = (int)$db->query("SELECT COUNT(*) FROM items")->fetchColumn();
$pendingClaims = (int)$db->query("SELECT COUNT(*) FROM claims WHERE status='pending'")->fetchColumn();
$activeLost    = (int)$db->query("SELECT COUNT(*) FROM items WHERE type='lost'  AND status='active'")->fetchColumn();
$activeFound   = (int)$db->query("SELECT COUNT(*) FROM items WHERE type='found' AND status='active'")->fetchColumn();
$totalClaimed  = (int)$db->query("SELECT COUNT(*) FROM items WHERE status='claimed'")->fetchColumn();

$recentClaims = $db->query("
    SELECT cl.*, i.title AS item_title, i.type AS item_type,
           u.name AS claimant_name
    FROM claims cl
    JOIN items i ON i.id = cl.item_id
    JOIN users u ON u.id = cl.claimant_id
    WHERE cl.status = 'pending'
    ORDER BY cl.created_at DESC
    LIMIT 5
")->fetchAll();

$recentItems = $db->query("
    SELECT i.*, u.name AS reporter_name
    FROM items i
    JOIN users u ON u.id = i.user_id
    ORDER BY i.created_at DESC
    LIMIT 5
")->fetchAll();
?>

<div class="admin-layout">
    
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <span><i class="fas fa-shield-alt"></i> Admin Panel</span>
            <small>YIC Lost &amp; Found</small>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php" class="active">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="items.php">
                <i class="fas fa-list"></i> Manage Items
            </a>
            <a href="claims.php">
                <i class="fas fa-hand-paper"></i> Manage Claims
                <?php if ($pendingClaims > 0): ?>
                    <span class="badge" style="margin-left:auto"><?= $pendingClaims ?></span>
                <?php endif; ?>
            </a>
            <a href="users.php">
                <i class="fas fa-users"></i> Manage Users
            </a>
            <a href="../index.php">
                <i class="fas fa-globe"></i> View Site
            </a>
            <a href="../logout.php" style="color:#f87171">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </nav>
    </aside>

    
    <div class="admin-main">
        <div class="admin-header">
            <h1>Dashboard</h1>
            <p>Welcome back, <?= e($user['name']) ?>. Here's what's happening.</p>
        </div>

        
        <div class="admin-stats">
            <div class="dash-stat">
                <div class="dash-stat-icon blue"><i class="fas fa-users"></i></div>
                <div>
                    <div class="dash-stat-num"><?= $totalUsers ?></div>
                    <div class="dash-stat-lbl">Total Students</div>
                </div>
            </div>
            <div class="dash-stat">
                <div class="dash-stat-icon red"><i class="fas fa-search"></i></div>
                <div>
                    <div class="dash-stat-num"><?= $activeLost ?></div>
                    <div class="dash-stat-lbl">Active Lost</div>
                </div>
            </div>
            <div class="dash-stat">
                <div class="dash-stat-icon green"><i class="fas fa-hand-holding"></i></div>
                <div>
                    <div class="dash-stat-num"><?= $activeFound ?></div>
                    <div class="dash-stat-lbl">Active Found</div>
                </div>
            </div>
            <div class="dash-stat">
                <div class="dash-stat-icon yellow"><i class="fas fa-hand-paper"></i></div>
                <div>
                    <div class="dash-stat-num"><?= $pendingClaims ?></div>
                    <div class="dash-stat-lbl">Pending Claims</div>
                </div>
            </div>
        </div>

        
        <div class="grid-2">
            
            <div>
                <div class="section-header">
                    <h2 style="font-size:1.1rem;font-weight:700">
                        <i class="fas fa-clock" style="color:var(--accent)"></i> Pending Claims
                    </h2>
                    <a href="claims.php" class="btn btn-outline btn-sm">View All</a>
                </div>
                <div style="background:var(--white);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden">
                    <?php if (empty($recentClaims)): ?>
                        <div class="empty-state" style="padding:32px">
                            <i class="fas fa-check" style="font-size:2rem;margin-bottom:8px;opacity:.3"></i>
                            <p>No pending claims!</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($recentClaims as $cl): ?>
                        <div style="padding:14px 16px;border-bottom:1px solid var(--border);display:flex;align-items:flex-start;gap:12px">
                            <div style="width:36px;height:36px;background:var(--warning-bg);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;color:var(--warning)">
                                <i class="fas fa-hand-paper"></i>
                            </div>
                            <div style="flex:1;min-width:0">
                                <p style="font-size:.88rem;font-weight:600;margin-bottom:2px">
                                    <?= e(mb_strimwidth($cl['item_title'], 0, 35, '…')) ?>
                                </p>
                                <p style="font-size:.8rem;color:var(--text-muted)">
                                    by <?= e($cl['claimant_name']) ?> &bull;
                                    <?= date('d M Y', strtotime($cl['created_at'])) ?>
                                </p>
                            </div>
                            <a href="claims.php?id=<?= $cl['id'] ?>" class="btn btn-accent btn-sm">Review</a>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            
            <div>
                <div class="section-header">
                    <h2 style="font-size:1.1rem;font-weight:700">
                        <i class="fas fa-clock" style="color:var(--primary)"></i> Recent Reports
                    </h2>
                    <a href="items.php" class="btn btn-outline btn-sm">View All</a>
                </div>
                <div style="background:var(--white);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden">
                    <?php foreach ($recentItems as $it): ?>
                    <div style="padding:14px 16px;border-bottom:1px solid var(--border);display:flex;align-items:flex-start;gap:12px">
                        <div class="dash-stat-icon <?= $it['type'] === 'lost' ? 'red' : 'green' ?>"
                             style="width:36px;height:36px;border-radius:50%;flex-shrink:0">
                            <i class="fas fa-<?= $it['type'] === 'lost' ? 'search' : 'hand-holding' ?>"></i>
                        </div>
                        <div style="flex:1;min-width:0">
                            <p style="font-size:.88rem;font-weight:600;margin-bottom:2px">
                                <a href="../item-detail.php?id=<?= $it['id'] ?>">
                                    <?= e(mb_strimwidth($it['title'], 0, 35, '…')) ?>
                                </a>
                            </p>
                            <p style="font-size:.8rem;color:var(--text-muted)">
                                by <?= e($it['reporter_name']) ?> &bull;
                                <?= date('d M Y', strtotime($it['created_at'])) ?>
                            </p>
                        </div>
                        <span class="badge-<?= $it['type'] ?>"><?= ucfirst($it['type']) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
