<?php
define('ADMIN_PAGE', true);
$pageTitle = 'Manage Users';
require_once '../includes/header.php';
requireAdmin();

$db = getDB();

/* ── Handle promote / demote ─────────────────────────────────── */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    $targetId = (int)($_POST['user_id'] ?? 0);
    $action   = $_POST['action'] ?? '';
    $me       = currentUser();

    if ($targetId && in_array($action, ['promote', 'demote'], true)) {

        // Can't change your own role
        if ($targetId === (int)$me['id']) {
            setFlash('error', 'You cannot change your own role.');

        } elseif ($action === 'demote') {
            // Prevent removing the last admin
            $adminCount = (int)$db->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
            if ($adminCount <= 1) {
                setFlash('error', 'Cannot demote the only remaining admin.');
            } else {
                $db->prepare("UPDATE users SET role='student' WHERE id=?")->execute([$targetId]);
                $target = $db->prepare("SELECT name FROM users WHERE id=?");
                $target->execute([$targetId]);
                $targetName = $target->fetchColumn();
                createNotification(
                    $targetId,
                    'Your admin privileges have been removed. You are now a Student.',
                    '../dashboard.php'
                );
                setFlash('success', e($targetName) . ' has been demoted to Student.');
            }

        } else { // promote
            $db->prepare("UPDATE users SET role='admin' WHERE id=?")->execute([$targetId]);
            $target = $db->prepare("SELECT name FROM users WHERE id=?");
            $target->execute([$targetId]);
            $targetName = $target->fetchColumn();
            createNotification(
                $targetId,
                'Congratulations! You have been promoted to Admin. You can now access the Admin Panel.',
                '../admin/dashboard.php'
            );
            setFlash('success', e($targetName) . ' has been promoted to Admin.');
        }
    }

    header('Location: users.php');
    exit;
}

/* ── Fetch users ─────────────────────────────────────────────── */
$pendingClaims = (int)$db->query("SELECT COUNT(*) FROM claims WHERE status='pending'")->fetchColumn();

$users = $db->query("
    SELECT u.*,
           COUNT(DISTINCT i.id) AS item_count,
           COUNT(DISTINCT c.id) AS claim_count
    FROM users u
    LEFT JOIN items  i ON i.user_id    = u.id
    LEFT JOIN claims c ON c.claimant_id = u.id
    GROUP BY u.id
    ORDER BY u.created_at DESC
")->fetchAll();

$me = currentUser();
?>

<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <span><i class="fas fa-shield-alt"></i> Admin Panel</span>
            <small>YIC Lost &amp; Found</small>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="items.php"><i class="fas fa-list"></i> Manage Items</a>
            <a href="claims.php">
                <i class="fas fa-hand-paper"></i> Manage Claims
                <?php if ($pendingClaims > 0): ?>
                    <span class="badge" style="margin-left:auto"><?= $pendingClaims ?></span>
                <?php endif; ?>
            </a>
            <a href="users.php" class="active"><i class="fas fa-users"></i> Manage Users</a>
            <a href="../index.php"><i class="fas fa-globe"></i> View Site</a>
            <a href="../logout.php" style="color:#f87171"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </nav>
    </aside>

    <div class="admin-main">
        <div class="admin-header">
            <h1>Manage Users</h1>
            <p>Promote students to admin or remove admin privileges.</p>
        </div>

        <div class="admin-stats" style="grid-template-columns:repeat(3,1fr);margin-bottom:24px">
            <div class="dash-stat">
                <div class="dash-stat-icon blue"><i class="fas fa-users"></i></div>
                <div>
                    <div class="dash-stat-num"><?= count($users) ?></div>
                    <div class="dash-stat-lbl">Total Users</div>
                </div>
            </div>
            <div class="dash-stat">
                <div class="dash-stat-icon green"><i class="fas fa-user-graduate"></i></div>
                <div>
                    <div class="dash-stat-num">
                        <?= count(array_filter($users, fn($u) => $u['role'] === 'student')) ?>
                    </div>
                    <div class="dash-stat-lbl">Students</div>
                </div>
            </div>
            <div class="dash-stat">
                <div class="dash-stat-icon yellow"><i class="fas fa-shield-alt"></i></div>
                <div>
                    <div class="dash-stat-num">
                        <?= count(array_filter($users, fn($u) => $u['role'] === 'admin')) ?>
                    </div>
                    <div class="dash-stat-lbl">Admins</div>
                </div>
            </div>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Role</th>
                        <th>Items</th>
                        <th>Claims</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                    <tr>
                        <td class="text-muted"><?= $u['id'] ?></td>
                        <td>
                            <div class="user-name-cell">
                                <div class="user-avatar">
                                    <?= mb_strtoupper(mb_substr($u['name'], 0, 1)) ?>
                                </div>
                                <div>
                                    <div class="font-bold"><?= e($u['name']) ?></div>
                                    <?php if ((int)$u['id'] === (int)$me['id']): ?>
                                        <div class="user-name-you">(you)</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td><?= e($u['email']) ?></td>
                        <td><?= $u['phone'] ? e($u['phone']) : '<span class="text-muted">–</span>' ?></td>
                        <td>
                            <?php if ($u['role'] === 'admin'): ?>
                                <span class="role-badge role-admin">
                                    <i class="fas fa-shield-alt"></i> Admin
                                </span>
                            <?php else: ?>
                                <span class="role-badge role-student">
                                    <i class="fas fa-user-graduate"></i> Student
                                </span>
                            <?php endif; ?>
                        </td>
                        <td><?= (int)$u['item_count'] ?></td>
                        <td><?= (int)$u['claim_count'] ?></td>
                        <td style="font-size:.85rem"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                        <td>
                            <?php if ((int)$u['id'] === (int)$me['id']): ?>
                                <span style="font-size:.8rem;color:var(--text-muted)">—</span>
                            <?php elseif ($u['role'] === 'student'): ?>
                                <form method="post" style="display:inline">
                                    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                                    <input type="hidden" name="user_id"   value="<?= $u['id'] ?>">
                                    <input type="hidden" name="action"    value="promote">
                                    <button type="submit" class="btn btn-sm promote-btn"
                                            data-confirm="Promote <?= e($u['name']) ?> to Admin? They will gain full access to the Admin Panel.">
                                        <i class="fas fa-arrow-up"></i> Make Admin
                                    </button>
                                </form>
                            <?php else: ?>
                                <form method="post" style="display:inline">
                                    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                                    <input type="hidden" name="user_id"   value="<?= $u['id'] ?>">
                                    <input type="hidden" name="action"    value="demote">
                                    <button type="submit" class="btn btn-sm demote-btn"
                                            data-confirm="Remove admin privileges from <?= e($u['name']) ?>? They will become a regular student.">
                                        <i class="fas fa-arrow-down"></i> Remove Admin
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
