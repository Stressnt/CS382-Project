<?php
define('ADMIN_PAGE', true);
$pageTitle = 'Manage Items';
require_once '../includes/header.php';
requireAdmin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $itemId = (int)($_POST['item_id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($itemId > 0) {
        if ($action === 'delete') {
            $db->prepare('DELETE FROM items WHERE id = ?')->execute([$itemId]);
            setFlash('success', 'Item deleted.');
        } elseif (in_array($action, ['active','claimed','closed'])) {
            $db->prepare('UPDATE items SET status = ? WHERE id = ?')->execute([$action, $itemId]);
            setFlash('success', 'Item status updated to ' . $action . '.');
        }
    }
    header('Location: items.php'); exit;
}

$typeFilter   = $_GET['type']   ?? '';
$statusFilter = $_GET['status'] ?? '';
$search       = trim($_GET['search'] ?? '');

$where  = [];
$params = [];

if ($typeFilter) { $where[] = 'i.type = ?'; $params[] = $typeFilter; }
if ($statusFilter) { $where[] = 'i.status = ?'; $params[] = $statusFilter; }
if ($search) {
    $where[]  = '(i.title LIKE ? OR i.location LIKE ?)';
    $like     = "%$search%";
    $params[] = $like; $params[] = $like;
}

$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$items = $db->prepare("
    SELECT i.*, u.name AS reporter_name,
           (SELECT COUNT(*) FROM claims c WHERE c.item_id = i.id) AS claim_count
    FROM items i
    JOIN users u ON u.id = i.user_id
    $whereSQL
    ORDER BY i.created_at DESC
");
$items->execute($params);
$itemsList = $items->fetchAll();

$pendingClaims = (int)$db->query("SELECT COUNT(*) FROM claims WHERE status='pending'")->fetchColumn();
?>

<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <span><i class="fas fa-shield-alt"></i> Admin Panel</span>
            <small>YIC Lost &amp; Found</small>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="items.php" class="active"><i class="fas fa-list"></i> Manage Items</a>
            <a href="claims.php">
                <i class="fas fa-hand-paper"></i> Manage Claims
                <?php if ($pendingClaims > 0): ?>
                    <span class="badge" style="margin-left:auto"><?= $pendingClaims ?></span>
                <?php endif; ?>
            </a>
            <a href="users.php"><i class="fas fa-users"></i> Manage Users</a>
            <a href="../index.php"><i class="fas fa-globe"></i> View Site</a>
            <a href="../logout.php" style="color:#f87171"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </nav>
    </aside>

    <div class="admin-main">
        <div class="admin-header">
            <h1>Manage Items</h1>
            <p>View, edit statuses, and delete reported items.</p>
        </div>

        
        <form method="GET" action="items.php">
            <div class="filter-bar" style="margin-bottom:20px">
                <div class="search-input-wrap">
                    <i class="fas fa-search"></i>
                    <input type="text" name="search" value="<?= e($search) ?>" placeholder="Search items…">
                </div>
                <div class="form-group" style="margin-bottom:0">
                    <select name="type" onchange="this.form.submit()">
                        <option value="">All Types</option>
                        <option value="lost"  <?= $typeFilter === 'lost'  ? 'selected' : '' ?>>Lost</option>
                        <option value="found" <?= $typeFilter === 'found' ? 'selected' : '' ?>>Found</option>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom:0">
                    <select name="status" onchange="this.form.submit()">
                        <option value="">All Status</option>
                        <option value="active"  <?= $statusFilter === 'active'  ? 'selected' : '' ?>>Active</option>
                        <option value="claimed" <?= $statusFilter === 'claimed' ? 'selected' : '' ?>>Claimed</option>
                        <option value="closed"  <?= $statusFilter === 'closed'  ? 'selected' : '' ?>>Closed</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary btn-sm">
                    <i class="fas fa-search"></i> Filter
                </button>
                <a href="items.php" class="btn btn-outline btn-sm"><i class="fas fa-times"></i> Clear</a>
            </div>
        </form>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Type</th>
                        <th>Category</th>
                        <th>Reporter</th>
                        <th>Location</th>
                        <th>Claims</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($itemsList)): ?>
                        <tr><td colspan="10" class="text-center" style="padding:40px;color:var(--text-muted)">
                            No items found.
                        </td></tr>
                    <?php endif; ?>
                    <?php foreach ($itemsList as $it): ?>
                    <tr>
                        <td style="color:var(--text-muted);font-size:.82rem">#<?= $it['id'] ?></td>
                        <td>
                            <a href="../item-detail.php?id=<?= $it['id'] ?>" style="font-weight:600">
                                <?= e(mb_strimwidth($it['title'], 0, 35, '…')) ?>
                            </a>
                        </td>
                        <td><span class="badge-<?= $it['type'] ?>"><?= ucfirst($it['type']) ?></span></td>
                        <td><?= e($it['category']) ?></td>
                        <td><?= e($it['reporter_name']) ?></td>
                        <td style="font-size:.85rem"><?= e(mb_strimwidth($it['location'], 0, 25, '…')) ?></td>
                        <td>
                            <?php if ($it['claim_count'] > 0): ?>
                                <a href="claims.php" style="font-weight:600;color:var(--primary)">
                                    <?= $it['claim_count'] ?>
                                </a>
                            <?php else: ?>
                                <span style="color:var(--text-muted)">0</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge-<?= $it['status'] ?>"><?= ucfirst($it['status']) ?></span></td>
                        <td style="font-size:.82rem"><?= date('d M Y', strtotime($it['created_at'])) ?></td>
                        <td>
                            <div class="flex gap-8">
                                
                                <form method="POST" action="items.php" style="display:inline">
                                    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                                    <input type="hidden" name="item_id" value="<?= $it['id'] ?>">
                                    <?php if ($it['status'] === 'active'): ?>
                                        <button name="action" value="closed" class="btn btn-outline btn-sm"
                                                title="Mark as Closed">
                                            <i class="fas fa-lock"></i>
                                        </button>
                                    <?php elseif ($it['status'] === 'closed'): ?>
                                        <button name="action" value="active" class="btn btn-success btn-sm"
                                                title="Reopen">
                                            <i class="fas fa-lock-open"></i>
                                        </button>
                                    <?php endif; ?>
                                </form>
                                
                                <a href="../report.php?edit=<?= $it['id'] ?>" class="btn btn-outline btn-sm"
                                   title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                
                                <form method="POST" action="items.php" style="display:inline">
                                    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                                    <input type="hidden" name="item_id" value="<?= $it['id'] ?>">
                                    <button name="action" value="delete" class="btn btn-danger btn-sm"
                                            data-confirm="Delete this item permanently? All associated claims will also be deleted."
                                            title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
